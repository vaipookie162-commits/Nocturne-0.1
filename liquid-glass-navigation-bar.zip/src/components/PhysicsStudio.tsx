import React from 'react';
import { PhysicsParams, TabSetMode } from '../types';
import { Sliders, RefreshCw, Layers, Zap, Palette } from 'lucide-react';

interface PhysicsStudioProps {
  physics: PhysicsParams;
  onChangePhysics: (updated: PhysicsParams) => void;
  onResetPhysics: () => void;
  tabSetMode: TabSetMode;
  onChangeTabSetMode: (mode: TabSetMode) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const PhysicsStudio: React.FC<PhysicsStudioProps> = ({
  physics,
  onChangePhysics,
  onResetPhysics,
  tabSetMode,
  onChangeTabSetMode,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const updateParam = (key: keyof PhysicsParams, value: number | boolean) => {
    onChangePhysics({
      ...physics,
      [key]: value,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg max-h-[90vh] bg-[#121212] border border-white/10 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col justify-between overflow-hidden text-gray-100">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold tracking-tight text-white">
                Liquid Physics & Shader Studio
              </h2>
              <p className="text-xs text-gray-400">Real-time Jetpack Compose & AGSL Tuning</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto my-4 pr-1 space-y-4 text-xs">
          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <label className="text-xs font-semibold text-gray-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#FF4E00]" />
              Tab Set Mode
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onChangeTabSetMode('standard')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all cursor-pointer ${
                  tabSetMode === 'standard'
                    ? 'bg-[#FF4E00] border-[#FF4E00] text-white shadow-md'
                    : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                Standard (Home, Card, Send, Assets)
              </button>
              <button
                onClick={() => onChangeTabSetMode('music')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition-all cursor-pointer ${
                  tabSetMode === 'music'
                    ? 'bg-[#FF4E00] border-[#FF4E00] text-white shadow-md'
                    : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
                }`}
              >
                Music (Explore, Search, Library, Favs)
              </button>
            </div>
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between font-medium">
              <span className="text-gray-300">Spring Stiffness</span>
              <span className="font-mono text-[#FF4E00]">{physics.stiffness}</span>
            </div>
            <input
              type="range"
              min={40}
              max={350}
              step={5}
              value={physics.stiffness}
              onChange={(e) => updateParam('stiffness', Number(e.target.value))}
              className="w-full accent-[#FF4E00] cursor-pointer"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between font-medium">
              <span className="text-gray-300">Spring Damping Ratio</span>
              <span className="font-mono text-[#FF4E00]">{physics.damping.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min={0.25}
              max={0.95}
              step={0.02}
              value={physics.damping}
              onChange={(e) => updateParam('damping', Number(e.target.value))}
              className="w-full accent-[#FF4E00] cursor-pointer"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between font-medium">
              <span className="text-gray-300">Morph Stretch Elongation</span>
              <span className="font-mono text-[#FF4E00]">{physics.stretchFactor.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min={0}
              max={1.5}
              step={0.05}
              value={physics.stretchFactor}
              onChange={(e) => updateParam('stretchFactor', Number(e.target.value))}
              className="w-full accent-[#FF4E00] cursor-pointer"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between font-medium">
              <span className="text-gray-300 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                AGSL RGB Split Aberration
              </span>
              <span className="font-mono text-amber-400">{(physics.rgbSplitStrength * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={0.08}
              step={0.005}
              value={physics.rgbSplitStrength}
              onChange={(e) => updateParam('rgbSplitStrength', Number(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="flex justify-between font-medium">
              <span className="text-gray-300">Edge Glow Bleed</span>
              <span className="font-mono text-[#FF4E00]">{(physics.glowIntensity * 100).toFixed(0)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={physics.glowIntensity}
              onChange={(e) => updateParam('glowIntensity', Number(e.target.value))}
              className="w-full accent-[#FF4E00] cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/5">
            <div className="space-y-0.5">
              <span className="font-semibold text-gray-200 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-[#FF4E00]" />
                Album Art Palette Reactivity
              </span>
              <p className="text-[10px] text-gray-500">
                Blend indicator color with active track art accent tint.
              </p>
            </div>
            <input
              type="checkbox"
              checked={physics.albumColorBleed}
              onChange={(e) => updateParam('albumColorBleed', e.target.checked)}
              className="w-5 h-5 accent-[#FF4E00] cursor-pointer rounded"
            />
          </div>
        </div>

        <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
          <button
            onClick={onResetPhysics}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors flex items-center gap-1.5 font-medium cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#FF4E00] hover:bg-[#F27D26] text-white font-semibold transition-colors cursor-pointer shadow-md shadow-[#FF4E00]/20"
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
