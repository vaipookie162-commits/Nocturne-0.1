import React from 'react';
import {
  CreditCard,
  Send as SendIcon,
  FolderHeart,
  Library as LibraryIcon,
  Sparkles,
  ArrowUpRight,
  CheckCircle2,
  HardDrive,
  Zap,
  Search,
  Star,
  Compass,
} from 'lucide-react';
import { Track } from '../types';

interface TabViewsProps {
  activeTabId: string;
  tracks: Track[];
  currentTrack: Track;
  onSelectTrack: (track: Track) => void;
  onSwitchToPlayer: () => void;
}

export const TabViews: React.FC<TabViewsProps> = ({
  activeTabId,
  tracks,
  currentTrack,
  onSelectTrack,
  onSwitchToPlayer,
}) => {
  switch (activeTabId) {
    case 'card':
      return (
        <div className="space-y-6 text-white animate-fade-in">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-2xl">
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-bold block mb-1">
                  Material 3 Wallet
                </span>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-[#FF4E00]" />
                  <span>SoundScape Hi-Fi Master Pass</span>
                </h2>
              </div>

              <span className="rounded-full bg-[#FF4E00]/20 px-3 py-1 text-[10px] font-mono font-bold text-[#FF4E00] border border-[#FF4E00]/30">
                PRO ACTIVE
              </span>
            </div>

            {/* Virtual Metallic Card Showcase */}
            <div className="relative h-52 w-full overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-tr from-[#1a1a1a] via-[#3a1510] to-[#0a0a0a] p-6 shadow-2xl">
              <div className="absolute top-0 right-0 h-44 w-44 rounded-full bg-[#FF4E00]/20 blur-3xl" />
              <div className="flex h-full flex-col justify-between relative z-10">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold tracking-wider text-gray-300 uppercase">
                    SOUNDSCAPE HI-FI AUDIO KEY
                  </span>
                  <Sparkles className="h-6 w-6 text-[#FF4E00]" />
                </div>

                <div>
                  <div className="text-[10px] text-gray-400 font-mono uppercase tracking-widest">
                    MASTER LICENSE ENGINE
                  </div>
                  <div className="text-xl font-mono font-bold text-white tracking-widest mt-1">
                    •••• •••• •••• 1208
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs font-mono text-gray-300">
                  <span>EXP: 12/28</span>
                  <span className="text-[#FF4E00]">BITRATE: 192kHz / 24-Bit FLAC</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      );

    case 'send':
      return (
        <div className="space-y-6 text-white animate-fade-in">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-2xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
                <SendIcon className="h-6 w-6" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-bold block">
                  Wi-Fi Direct Stream
                </span>
                <h2 className="text-xl font-bold text-white">Nearby Share & Audio Stream</h2>
              </div>
            </div>

            <div className="rounded-3xl bg-black/40 p-8 border border-white/5 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30 animate-pulse">
                <Zap className="h-8 w-8" />
              </div>
              <h3 className="mt-4 text-base font-bold text-white">Scanning for Nearby Receivers...</h3>
              <p className="mt-2 text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                Ultra-low latency Wi-Fi Direct streaming ready to transfer lossless audio files or sync active multi-room playback.
              </p>
            </div>
          </div>
        </div>
      );

    case 'assets':
      return (
        <div className="space-y-6 text-white animate-fade-in">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-2xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
                <FolderHeart className="h-6 w-6" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-bold block">
                  Hardware Presets
                </span>
                <h2 className="text-xl font-bold text-white">Audio Assets & AGSL Shader Materials</h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-white/5 bg-black/40 p-5">
                <div className="flex items-center gap-2 text-[#FF4E00] text-sm font-bold">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>AGSL Gooey Metashader v3.2</span>
                </div>
                <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                  Compiled for Android API 33+ with hardware render node velocity deformation acceleration.
                </p>
              </div>

              <div className="rounded-2xl border border-white/5 bg-black/40 p-5">
                <div className="flex items-center gap-2 text-[#FF4E00] text-sm font-bold">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Parametric 10-Band DSP Equalizer</span>
                </div>
                <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                  Zero phase distortion with dynamic bass boost and high frequency clarity filter.
                </p>
              </div>
            </div>
          </div>
        </div>
      );

    case 'library':
    case 'search':
    case 'favs':
      return (
        <div className="space-y-4 text-white animate-fade-in">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-2xl">
            <div className="flex items-center justify-between mb-6">
              <div>
                <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-bold block mb-1">
                  Local Library
                </span>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <LibraryIcon className="h-5 w-5 text-[#FF4E00]" />
                  <span>Music Tracks & Master FLAC Files</span>
                </h2>
              </div>
              <span className="text-xs font-mono text-gray-400">{tracks.length} Master Files</span>
            </div>

            <div className="space-y-3">
              {tracks.map((track) => (
                <div
                  key={track.id}
                  onClick={() => {
                    onSelectTrack(track);
                    onSwitchToPlayer();
                  }}
                  className="flex items-center justify-between rounded-2xl bg-black/40 p-3.5 hover:bg-white/10 cursor-pointer border border-white/5 transition-all"
                >
                  <div className="flex items-center gap-3.5">
                    <img src={track.coverUrl} className="h-12 w-12 rounded-xl object-cover" alt="" />
                    <div>
                      <h4 className="text-sm font-bold text-white">{track.title}</h4>
                      <p className="text-xs text-gray-400">{track.artist} • {track.album}</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-[#FF4E00]">{track.duration}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      );

    default:
      return null;
  }
};
