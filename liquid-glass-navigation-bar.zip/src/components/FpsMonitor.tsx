import React, { useEffect, useState } from 'react';
import { Activity, Gauge, Zap, BatteryCharging, ShieldCheck } from 'lucide-react';

export const FpsMonitor: React.FC = () => {
  const [fps, setFps] = useState(120);
  const [frameTime, setFrameTime] = useState(8.33);
  const [history, setHistory] = useState<number[]>(Array(24).fill(120));

  useEffect(() => {
    let frameCount = 0;
    let lastTime = performance.now();
    let animId: number;

    const measure = (time: number) => {
      frameCount++;
      const delta = time - lastTime;

      if (delta >= 500) {
        const calculatedFps = Math.min(120, Math.round((frameCount * 1000) / delta));
        const ms = (delta / frameCount).toFixed(2);

        setFps(calculatedFps);
        setFrameTime(Number(ms));
        setHistory((prev) => [...prev.slice(1), calculatedFps]);

        frameCount = 0;
        lastTime = time;
      }

      animId = requestAnimationFrame(measure);
    };

    animId = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="w-full max-w-5xl mx-auto my-6 p-4 sm:p-5 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-2xl shadow-2xl text-white">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
            <Gauge className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-mono font-bold block">
              TARGET FPS
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base font-extrabold text-white font-mono">{fps}</span>
              <span className="text-[10px] text-[#FF4E00] font-bold font-mono">/ 120 Hz</span>
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-white/10 text-gray-300 border border-white/10">
            <Activity className="w-4 h-4 text-[#FF4E00]" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-mono font-bold block">
              FRAME LATENCY
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-base font-extrabold text-white font-mono">{frameTime}</span>
              <span className="text-[10px] text-gray-400 font-mono">ms</span>
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-mono font-bold block">
              GPU THREAD
            </span>
            <span className="text-xs font-bold text-gray-200 flex items-center gap-1 font-mono">
              <ShieldCheck className="w-3 h-3 text-[#FF4E00]" />
              Isolated Layer
            </span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <BatteryCharging className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-mono font-bold block">
              BATTERY IMPACT
            </span>
            <span className="text-xs font-bold text-[#FF4E00] font-mono">Ultra-Low (&lt; 0.8%)</span>
          </div>
        </div>
      </div>

      <div className="mt-4 pt-3 border-t border-white/5 flex items-center gap-2 h-7">
        <span className="text-[10px] text-gray-500 font-mono tracking-widest uppercase shrink-0">120 FPS Realtime</span>
        <div className="flex-1 flex items-end h-full gap-0.5">
          {history.map((val, idx) => (
            <div
              key={idx}
              className="flex-1 rounded-t bg-gradient-to-t from-[#FF4E00] to-[#F27D26] opacity-80 transition-all duration-300"
              style={{
                height: `${Math.max(20, (val / 120) * 100)}%`,
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
