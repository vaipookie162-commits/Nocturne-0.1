import React, { useEffect, useRef } from 'react';
import { NavItem, PhysicsParams } from '../types';
import * as Icons from 'lucide-react';

interface LiquidGlassNavbarProps {
  items: NavItem[];
  activeIndex: number;
  onSelectTab: (index: number) => void;
  physics: PhysicsParams;
  accentColor?: string;
  className?: string;
}

export const LiquidGlassNavbar: React.FC<LiquidGlassNavbarProps> = ({
  items,
  activeIndex,
  onSelectTab,
  physics,
  accentColor = '#FFFFFF',
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const stateRef = useRef({
    currentPos: activeIndex,
    targetPos: activeIndex,
    velocity: 0,
    stretchFactor: 0,
    lastTime: performance.now(),
    width: 0,
    height: 0,
    dpr: 1,
    colorRgb: { r: 255, g: 255, b: 255 },
    targetRgb: { r: 255, g: 255, b: 255 },
  });

  const hexToRgb = (hex: string) => {
    let cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map((c) => c + c).join('');
    }
    const num = parseInt(cleanHex, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255,
    };
  };

  useEffect(() => {
    if (physics.albumColorBleed && accentColor) {
      stateRef.current.targetRgb = hexToRgb(accentColor);
    } else {
      stateRef.current.targetRgb = { r: 255, g: 255, b: 255 };
    }
  }, [accentColor, physics.albumColorBleed]);

  useEffect(() => {
    stateRef.current.targetPos = activeIndex;
  }, [activeIndex]);

  useEffect(() => {
    let animFrameId: number;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);

      stateRef.current.width = rect.width;
      stateRef.current.height = rect.height;
      stateRef.current.dpr = dpr;

      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const render = (time: number) => {
      const state = stateRef.current;
      const dt = Math.min((time - state.lastTime) / 1000, 0.032);
      state.lastTime = time;

      const dx = state.targetPos - state.currentPos;
      const springForce = dx * physics.stiffness;
      const dampingForce = -state.velocity * (physics.damping * 20);
      const accel = (springForce + dampingForce) / physics.mass;

      state.velocity += accel * dt;
      state.currentPos += state.velocity * dt;

      const colorSpeed = 8;
      state.colorRgb.r += (state.targetRgb.r - state.colorRgb.r) * dt * colorSpeed;
      state.colorRgb.g += (state.targetRgb.g - state.colorRgb.g) * dt * colorSpeed;
      state.colorRgb.b += (state.targetRgb.b - state.colorRgb.b) * dt * colorSpeed;

      const { width, height, dpr } = state;
      if (width > 0 && height > 0) {
        ctx.clearRect(0, 0, width * dpr, height * dpr);
        ctx.save();
        ctx.scale(dpr, dpr);

        const itemCount = items.length;
        const itemWidth = width / itemCount;
        const pillHeight = height * physics.pillHeightRatio;
        const pillY = (height - pillHeight) / 2;
        const pillRadius = pillHeight / 2;

        const centerPos = (state.currentPos + 0.5) * itemWidth;
        const speed = Math.abs(state.velocity);
        const moveDir = Math.sign(state.velocity);

        const stretchX = Math.min(speed * physics.stretchFactor * 18, itemWidth * 0.7);
        const pillWidth = Math.max(itemWidth * 0.65, itemWidth * 0.55 + stretchX);

        const leadX = centerPos + moveDir * (stretchX * 0.5);
        const tailX = centerPos - moveDir * (stretchX * 0.5);

        const r = Math.round(state.colorRgb.r);
        const g = Math.round(state.colorRgb.g);
        const b = Math.round(state.colorRgb.b);
        const activeColor = `rgb(${r}, ${g}, ${b})`;

        const rgbOffset = Math.min(speed * physics.rgbSplitStrength * 12, 16);

        const drawLiquidShape = (
          cx: number,
          cy: number,
          w: number,
          h: number,
          fillColor: string,
          offX: number = 0,
          globalAlpha: number = 1
        ) => {
          ctx.save();
          ctx.globalAlpha = globalAlpha;

          const left = cx - w / 2 + offX;
          const right = cx + w / 2 + offX;
          const top = cy;
          const bottom = cy + h;
          const rad = h / 2;

          ctx.beginPath();
          ctx.moveTo(left + rad, top);
          ctx.lineTo(right - rad, top);
          ctx.arcTo(right, top, right, cy + rad, rad);
          ctx.arcTo(right, bottom, right - rad, bottom, rad);
          ctx.lineTo(left + rad, bottom);
          ctx.arcTo(left, bottom, left, cy + rad, rad);
          ctx.arcTo(left, top, left + rad, top, rad);
          ctx.closePath();

          ctx.fillStyle = fillColor;

          if (physics.glowIntensity > 0) {
            ctx.shadowColor = `rgba(${r}, ${g}, ${b}, ${0.4 * physics.glowIntensity})`;
            ctx.shadowBlur = 12 * physics.glowIntensity;
          }

          ctx.fill();

          if (stretchX > 5) {
            const bridgeMidX = (leadX + tailX) / 2;
            const bridgeTopY = top + h * 0.2;
            const bridgeBottomY = bottom - h * 0.2;

            ctx.beginPath();
            ctx.moveTo(tailX, bridgeTopY);
            ctx.quadraticCurveTo(bridgeMidX, top + h * 0.35, leadX, bridgeTopY);
            ctx.lineTo(leadX, bridgeBottomY);
            ctx.quadraticCurveTo(bridgeMidX, bottom - h * 0.35, tailX, bridgeBottomY);
            ctx.closePath();

            ctx.fillStyle = fillColor;
            ctx.fill();
          }

          ctx.restore();
        };

        if (rgbOffset > 0.5 && physics.rgbSplitStrength > 0) {
          drawLiquidShape(centerPos, pillY, pillWidth, pillHeight, `rgba(255, 50, 80, 0.75)`, moveDir * rgbOffset, 0.85);
          drawLiquidShape(centerPos, pillY, pillWidth, pillHeight, `rgba(0, 230, 255, 0.75)`, -moveDir * rgbOffset, 0.85);
        }

        drawLiquidShape(centerPos, pillY, pillWidth, pillHeight, activeColor, 0, 1.0);

        ctx.beginPath();
        const glassLeft = centerPos - pillWidth / 2 + pillRadius * 0.5;
        const glassRight = centerPos + pillWidth / 2 - pillRadius * 0.5;
        ctx.moveTo(glassLeft, pillY + 3);
        ctx.lineTo(glassRight, pillY + 3);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.lineCap = 'round';
        ctx.stroke();

        ctx.restore();
      }

      animFrameId = requestAnimationFrame(render);
    };

    animFrameId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animFrameId);
    };
  }, [items, physics]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-[76px] sm:h-[80px] max-w-md mx-auto select-none ${className}`}
    >
      {/* Decorative Blur Underlay for Bottom Glow */}
      <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-4/5 h-4 bg-[#FF4E00] blur-3xl opacity-25 pointer-events-none" />

      {/* Capsule Container */}
      <div className="absolute inset-0 rounded-full bg-[#121212]/90 backdrop-blur-2xl border border-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.5)] overflow-hidden">
        <div className="absolute inset-x-6 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />

        <canvas
          ref={canvasRef}
          className="absolute inset-0 pointer-events-none z-10"
        />

        <div className="relative z-20 w-full h-full flex items-center justify-around px-2">
          {items.map((item, index) => {
            const isActive = activeIndex === index;

            const IconComponent = (Icons as unknown as Record<string, React.FC<{ className?: string }>>)[
              item.iconName
            ] || Icons.Compass;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(index)}
                className="relative flex-1 h-full flex flex-col items-center justify-center gap-1 transition-transform duration-200 active:scale-90 focus:outline-none group cursor-pointer"
                aria-label={item.label}
              >
                {item.badge && (
                  <span className="absolute top-2.5 right-[calc(50%-16px)] px-1.5 py-0.5 text-[10px] font-bold tracking-tight rounded-full bg-[#FF4E00] text-white shadow-md z-30 animate-pulse">
                    {item.badge}
                  </span>
                )}

                <div
                  className={`transition-all duration-300 transform ${
                    isActive ? 'scale-110 -translate-y-0.5 text-black font-bold' : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  <IconComponent className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.2]" />
                </div>

                <span
                  className={`text-[10px] font-medium tracking-tight transition-colors duration-200 ${
                    isActive ? 'text-black font-bold' : 'text-gray-400/80 group-hover:text-gray-300'
                  }`}
                >
                  {item.label}
                </span>

                <div className="absolute inset-2 rounded-full bg-white/0 group-active:bg-white/10 transition-colors pointer-events-none" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
