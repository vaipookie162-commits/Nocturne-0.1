import React, { useState } from 'react';
import { X, Copy, Check, Smartphone, ShieldCheck, Terminal } from 'lucide-react';

interface AgslCodeViewerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AgslCodeViewer: React.FC<AgslCodeViewerProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const agslShaderCode = `// ====================================================================
// AGSL (Android Graphics Shading Language) Liquid Glass + RGB Split
// Targeted for API Level 33+ (Android 13+ Jetpack Compose)
// ====================================================================

// 1. GLSL Runtime Shader String definition
const val LIQUID_GLASS_AGSL = """
    uniform float2 size;
    uniform float progress;      // Animation progress (0.0 to 1.0)
    uniform float moveDirection; // -1.0 for left, 1.0 for right
    uniform float velocity;      // Particle speed factor
    uniform shader composable;

    half4 main(float2 fragCoord) {
        float strength = 0.018 * velocity;
        
        // Chromatic Aberration / RGB Split Channel Extraction
        float r = composable.eval(fragCoord + float2(strength * moveDirection, 0.0)).r;
        float g = composable.eval(fragCoord).g;
        float b = composable.eval(fragCoord - float2(strength * moveDirection, 0.0)).b;
        
        half4 color = half4(r, g, b, 1.0);
        
        // Liquid Alpha Thresholding (Gooey Metashader Threshold)
        float alpha = color.a;
        if (alpha < 0.48) {
            alpha = 0.0;
        } else {
            alpha = 1.0;
        }
        
        return half4(color.rgb, alpha);
    }
"""

// 2. Jetpack Compose Custom Composable Implementation
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CapsuleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

@Composable
fun LiquidGlassNavigationBar(
    items: List<Pair<String, ImageVector>>,
    selectedIndex: Int,
    onSelectTab: (Int) -> Unit
) {
    val indicatorOffset by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = 0.6f, // Organic spring bounce
            stiffness = Spring.StiffnessLow
        ),
        label = "indicator"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
            .height(80.dp),
        contentAlignment = Alignment.Center
    ) {
        // Floating Dark Capsule Container
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    clip = true
                    shape = CapsuleShape
                    shadowElevation = 24f
                }
                .background(Color(0xFF121212).copy(alpha = 0.92f))
        ) {
            // Liquid Canvas RenderEffect Layer
            CanvasLayer(
                itemCount = items.size,
                indicatorOffset = indicatorOffset,
                color = Color.White
            )

            // Interactive Icons Row
            Row(modifier = Modifier.fillMaxSize()) {
                items.forEachIndexed { index, item ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onSelectTab(index) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.second,
                            contentDescription = item.first,
                            tint = if (selectedIndex == index) Color.Black else Color.Gray.copy(alpha = 0.6f),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }
    }
}
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(agslShaderCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-fade-in">
      <div className="relative flex max-h-[90vh] w-full max-w-3xl flex-col rounded-3xl border border-white/15 bg-neutral-900 shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4 bg-neutral-950">
          <div className="flex items-center space-x-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Terminal className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Android AGSL & Jetpack Compose Source</span>
                <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-[10px] font-mono text-emerald-300 border border-emerald-500/30">
                  API 33+ Optimized
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                120fps RenderNode + AGSL Liquid Shader
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-indigo-500 active:scale-95 transition-all shadow-md"
            >
              {copied ? <Check className="h-4 w-4 text-emerald-300" /> : <Copy className="h-4 w-4" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-full p-2 text-neutral-400 hover:bg-white/10 hover:text-white transition-all"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Code Content Container */}
        <div className="overflow-y-auto p-6 bg-neutral-950 font-mono text-xs leading-relaxed text-neutral-300">
          <pre className="whitespace-pre-wrap select-text">{agslShaderCode}</pre>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-white/10 px-6 py-3 bg-neutral-900 text-xs text-neutral-400">
          <div className="flex items-center space-x-2">
            <Smartphone className="h-4 w-4 text-emerald-400" />
            <span>Hardware Accelerated on Android RenderThread</span>
          </div>
          <span>Material 3 Expressive UI</span>
        </div>
      </div>
    </div>
  );
};
