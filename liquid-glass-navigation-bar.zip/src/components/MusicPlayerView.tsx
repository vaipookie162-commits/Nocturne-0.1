import React, { useState, useEffect, useRef } from 'react';
import { NavItem, PhysicsParams, Track } from '../types';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Heart,
  Shuffle,
  Repeat,
  Disc3,
  Share2,
  Sparkles,
  Music2,
  Radio,
  Sliders,
  Volume2,
} from 'lucide-react';
import { LiquidGlassNavbar } from './LiquidGlassNavbar';
import { TabViews } from './TabViews';

interface MusicPlayerViewProps {
  tracks: Track[];
  currentTrack: Track;
  onSelectTrack: (track: Track) => void;
  items: NavItem[];
  activeTabIndex: number;
  onSelectTab: (index: number) => void;
  physics: PhysicsParams;
  deviceFrame: boolean;
  onToggleFrame: () => void;
  onOpenPhysicsStudio: () => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
}

export const MusicPlayerView: React.FC<MusicPlayerViewProps> = ({
  tracks,
  currentTrack,
  onSelectTrack,
  items,
  activeTabIndex,
  onSelectTab,
  physics,
  deviceFrame,
  onToggleFrame,
  onOpenPhysicsStudio,
  isPlaying,
  onTogglePlay,
}) => {
  const [currentTime, setCurrentTime] = useState(42);
  const [isLiked, setIsLiked] = useState(false);
  const spectrumCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const activeTabId = items[activeTabIndex]?.id || 'home';

  // Auto-increment track playback position when playing
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentTime((prev) => {
          const maxSec = currentTrack.durationSeconds || 240;
          if (prev >= maxSec) return 0;
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaying, currentTrack]);

  // Audio Spectrum Canvas Equalizer
  useEffect(() => {
    const canvas = spectrumCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;

    const renderSpectrum = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const barCount = 28;
      const barWidth = canvas.width / barCount - 2;

      for (let i = 0; i < barCount; i++) {
        const heightFactor = isPlaying
          ? Math.sin(phase + i * 0.35) * 0.45 + 0.55
          : 0.15;
        const barHeight = heightFactor * (canvas.height * 0.85);
        const x = i * (barWidth + 2);
        const y = canvas.height - barHeight;

        const grad = ctx.createLinearGradient(0, canvas.height, 0, y);
        grad.addColorStop(0, '#FF4E00');
        grad.addColorStop(1, '#F27D26');

        ctx.fillStyle = grad;
        ctx.beginPath();
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 0, 0]);
        } else {
          ctx.rect(x, y, barWidth, barHeight);
        }
        ctx.fill();
      }

      phase += 0.12;
      animId = requestAnimationFrame(renderSpectrum);
    };

    renderSpectrum();
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, currentTrack]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const durationMax = currentTrack.durationSeconds || 240;

  return (
    <div
      className={`w-full transition-all duration-500 ${
        deviceFrame
          ? 'max-w-5xl rounded-[44px] sm:rounded-[52px] border border-white/10 bg-[#050505] shadow-[0_25px_60px_-15px_rgba(255,78,0,0.15)] p-5 sm:p-8 relative overflow-hidden'
          : 'w-full'
      }`}
    >
      {/* Background Subtle Gradient Mesh inside Frame */}
      <div
        className="pointer-events-none absolute -top-32 -left-32 w-96 h-96 rounded-full blur-[140px] opacity-20 transition-all duration-700"
        style={{ backgroundColor: currentTrack.accentColor || '#FF4E00' }}
      />

      {/* Main Content Layout */}
      <div className="relative z-10 flex flex-col gap-8">
        {/* Render TabViews if not on primary home / player view */}
        {activeTabId !== 'home' && activeTabId !== 'explore' ? (
          <div className="min-h-[460px]">
            <TabViews
              activeTabId={activeTabId}
              tracks={tracks}
              currentTrack={currentTrack}
              onSelectTrack={onSelectTrack}
              onSwitchToPlayer={() => onSelectTab(0)}
            />
          </div>
        ) : (
          /* Immersive UI Main Hero & Queue View */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Now Playing Hero Card */}
            <div className="lg:col-span-7 flex flex-col">
              <div className="relative group aspect-square w-full max-w-md mx-auto lg:max-w-none rounded-[40px] overflow-hidden shadow-2xl shadow-[#FF4E00]/10 border border-white/5 bg-[#121212]">
                <img
                  src={currentTrack.coverUrl}
                  alt={currentTrack.album}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent z-10" />

                {/* Top Badge Overlay */}
                <div className="absolute top-6 left-6 right-6 z-20 flex justify-between items-center">
                  <span className="text-[10px] uppercase tracking-[0.2em] font-mono font-bold text-white/80 bg-black/60 px-3 py-1 rounded-full border border-white/10 backdrop-blur-md">
                    {currentTrack.bitrate || '24-BIT / 192KHZ'}
                  </span>
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all backdrop-blur-md ${
                      isLiked
                        ? 'bg-[#FF4E00] text-white border-[#FF4E00]'
                        : 'bg-black/40 text-white/80 border-white/20 hover:bg-black/60'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isLiked ? 'fill-white' : ''}`} />
                  </button>
                </div>

                {/* Track Title Overlay */}
                <div className="absolute bottom-8 left-8 right-8 z-20">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#FF4E00] font-mono font-bold block mb-1">
                    {currentTrack.genre || 'Master Audio'}
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white leading-tight">
                    {currentTrack.title}
                  </h2>
                  <p className="text-[#FF4E00] text-base sm:text-lg font-medium opacity-90 mt-1">
                    {currentTrack.artist} • <span className="text-gray-300">{currentTrack.album}</span>
                  </p>
                </div>
              </div>

              {/* Playback Progress & Scrubber */}
              <div className="mt-6 flex flex-col gap-4">
                <div className="w-full">
                  <div className="relative group cursor-pointer py-2">
                    <input
                      type="range"
                      min={0}
                      max={durationMax}
                      value={currentTime}
                      onChange={(e) => setCurrentTime(Number(e.target.value))}
                      className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-[#FF4E00]"
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500 font-mono tracking-widest uppercase mt-1">
                    <span>{formatTime(currentTime)}</span>
                    <span>{currentTrack.duration}</span>
                  </div>
                </div>

                {/* Equalizer Waveform Canvas */}
                <div className="rounded-2xl bg-white/5 p-2.5 border border-white/5 flex items-center gap-3">
                  <Sparkles className="w-4 h-4 text-[#FF4E00] shrink-0" />
                  <canvas ref={spectrumCanvasRef} width={300} height={28} className="w-full h-7" />
                </div>

                {/* Playback Controls Row */}
                <div className="flex justify-between items-center px-4 pt-2">
                  <button className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    <Shuffle className="w-5 h-5" />
                  </button>

                  <div className="flex items-center gap-6">
                    <button
                      onClick={() => {
                        const idx = tracks.findIndex((t) => t.id === currentTrack.id);
                        const prevIdx = (idx - 1 + tracks.length) % tracks.length;
                        onSelectTrack(tracks[prevIdx]);
                      }}
                      className="text-gray-300 hover:text-white transition-transform active:scale-90 cursor-pointer"
                    >
                      <SkipBack className="w-6 h-6 fill-current" />
                    </button>

                    <button
                      onClick={onTogglePlay}
                      className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-xl shadow-white/10 text-black hover:scale-105 active:scale-95 transition-all cursor-pointer"
                    >
                      {isPlaying ? (
                        <Pause className="w-8 h-8 fill-black" />
                      ) : (
                        <Play className="w-8 h-8 fill-black ml-1" />
                      )}
                    </button>

                    <button
                      onClick={() => {
                        const idx = tracks.findIndex((t) => t.id === currentTrack.id);
                        const nextIdx = (idx + 1) % tracks.length;
                        onSelectTrack(tracks[nextIdx]);
                      }}
                      className="text-gray-300 hover:text-white transition-transform active:scale-90 cursor-pointer"
                    >
                      <SkipForward className="w-6 h-6 fill-current" />
                    </button>
                  </div>

                  <button className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    <Repeat className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Right: Queue / Local Track List */}
            <div className="lg:col-span-5 flex flex-col h-full justify-between gap-6">
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xs uppercase tracking-[0.2em] text-gray-500 font-bold">
                    Up Next
                  </h3>
                  <span className="text-xs text-[#FF4E00] font-medium font-mono cursor-pointer hover:underline">
                    Clear Queue
                  </span>
                </div>

                <div className="flex flex-col gap-3">
                  {tracks.map((track) => {
                    const isSelected = track.id === currentTrack.id;
                    return (
                      <div
                        key={track.id}
                        onClick={() => onSelectTrack(track)}
                        className={`flex items-center gap-4 p-4 rounded-3xl transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-white/10 border-[#FF4E00]/40 shadow-lg shadow-[#FF4E00]/10'
                            : 'bg-white/5 border-white/5 hover:bg-white/10'
                        }`}
                      >
                        <div className="relative w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-white/10 bg-black/40">
                          <img
                            src={track.coverUrl}
                            alt={track.title}
                            className="w-full h-full object-cover"
                          />
                          {isSelected && isPlaying && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <Disc3 className="w-6 h-6 text-[#FF4E00] animate-spin" />
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <h4 className={`text-sm font-semibold truncate ${isSelected ? 'text-[#FF4E00]' : 'text-white'}`}>
                            {track.title}
                          </h4>
                          <p className="text-xs text-gray-400 truncate">
                            {track.artist} • {track.album}
                          </p>
                        </div>

                        <span className="text-[10px] text-gray-500 font-mono shrink-0">
                          {track.duration}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* High-Fi Feature Highlights */}
              <div className="p-5 rounded-3xl bg-white/5 border border-white/5 backdrop-blur-md">
                <div className="flex items-center justify-between text-xs text-gray-400 font-mono mb-2">
                  <span className="uppercase tracking-widest text-[10px] text-gray-500 font-bold">
                    HARDWARE ACCELERATED
                  </span>
                  <span className="text-[#FF4E00]">AGSL Shader v3.2</span>
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">
                  Real-time 120 FPS chromatic aberration and liquid glass morphing rendered directly on GPU RenderNode.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Floating Liquid Glass Bottom Navbar */}
        <div className="pt-4 pb-2 w-full flex justify-center">
          <LiquidGlassNavbar
            items={items}
            activeIndex={activeTabIndex}
            onSelectTab={onSelectTab}
            physics={physics}
            accentColor={currentTrack.accentColor || '#FF4E00'}
          />
        </div>
      </div>
    </div>
  );
};
