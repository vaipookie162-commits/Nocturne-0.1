import React, { useState } from 'react';
import { AGSL_SHADER_CODE, JETPACK_COMPOSE_KOTLIN_CODE } from '../data/musicData';
import { Copy, Check, Code2, Cpu, Terminal } from 'lucide-react';

export const CodeInspector: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'kotlin' | 'agsl'>('kotlin');
  const [copied, setCopied] = useState(false);

  const currentCode = activeTab === 'kotlin' ? JETPACK_COMPOSE_KOTLIN_CODE : AGSL_SHADER_CODE;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-5xl mx-auto my-8 p-5 sm:p-6 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-2xl shadow-2xl text-white">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              Android Source Code
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30 font-mono">
                Material 3 & AGSL
              </span>
            </h3>
            <p className="text-xs text-gray-400">
              Copy-pasteable Jetpack Compose Kotlin UI & Android 13+ Shader Code
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center p-1 rounded-2xl bg-black/40 border border-white/10">
            <button
              onClick={() => setActiveTab('kotlin')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'kotlin' ? 'bg-[#FF4E00] text-white shadow-md' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              Jetpack Compose (.kt)
            </button>
            <button
              onClick={() => setActiveTab('agsl')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'agsl' ? 'bg-[#FF4E00] text-white shadow-md' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              AGSL Shader (.glsl)
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-xs font-semibold text-white transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#FF4E00]" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                Copy Code
              </>
            )}
          </button>
        </div>
      </div>

      <div className="mt-4 relative rounded-2xl bg-black/60 border border-white/5 p-4 overflow-x-auto max-h-[420px] font-mono text-xs leading-relaxed text-gray-300 select-all no-scrollbar">
        <pre>{currentCode}</pre>
      </div>
    </div>
  );
};
