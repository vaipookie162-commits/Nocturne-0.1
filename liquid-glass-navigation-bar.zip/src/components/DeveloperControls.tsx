import React from 'react';
import { PhysicsConfig } from '../types';
import {
  Sliders,
  Zap,
  Battery,
  Sparkles,
  Code2,
  RefreshCw,
  Palette,
  Activity,
} from 'lucide-react';

interface DeveloperControlsProps {
  config: PhysicsConfig;
  onChange: (updated: PhysicsConfig) => void;
  fps: number;
  onOpenAgslCode: () => void;
  onTriggerPulse: () => void;
  tabMode: 'custom' | 'music';
  onToggleTabMode: (mode: 'custom' | 'music') => void;
}

export const DeveloperControls: React.FC<DeveloperControlsProps> = ({
  config,
  onChange,
  fps,
  onOpenAgslCode,
  onTriggerPulse,
  tabMode,
  onToggleTabMode,
}) => {
  return (
    <div className="rounded-3xl border border-white/10 bg-neutral-900/90 p-5 backdrop-blur-xl shadow-2xl text-white">
      {/* Header with FPS and Quick Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Sliders className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wide">
              Liquid Shader Inspector
            </h3>
            <p className="text-xs text-neutral-400">
              AGSL / Jetpack Compose Material 3 Simulator
            </p>
          </div>
        </div>

        {/* Real-time FPS Metric Badge */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-mono font-bold text-emerald-400">
            <Activity className="h-3.5 w-3.5 animate-pulse" />
            <span>{fps} FPS</span>
          </div>

          <button
            onClick={onOpenAgslCode}
            className="flex items-center space-x-1.5 rounded-full border border-indigo-500/30 bg-indigo-500/20 px-3 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-indigo-500/30 transition-all active:scale-95"
          >
            <Code2 className="h-3.5 w-3.5" />
            <span>View AGSL Shader</span>
          </button>
        </div>
      </div>

      {/* Physics & Shader Parameter Controls Grid */}
      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Stiffness Control */}
        <div className="rounded-2xl bg-neutral-800/50 p-3.5 border border-white/5">
          <div className="flex items-center justify-between text-xs font-medium text-neutral-300">
            <span>Spring Stiffness</span>
            <span className="font-mono text-indigo-400">{config.stiffness}</span>
          </div>
          <input
            type="range"
            min="100"
            max="700"
            step="10"
            value={config.stiffness}
            onChange={(e) => onChange({ ...config, stiffness: Number(e.target.value) })}
            className="mt-2.5 h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-neutral-700 accent-indigo-500"
          />
          <span className="mt-1 block text-[10px] text-neutral-500">Higher = Faster snap</span>
        </div>

        {/* Damping Control */}
        <div className="rounded-2xl bg-neutral-800/50 p-3.5 border border-white/5">
          <div className="flex items-center justify-between text-xs font-medium text-neutral-300">
            <span>Damping Ratio (Bounce)</span>
            <span className="font-mono text-pink-400">{config.damping.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.2"
            max="0.9"
            step="0.02"
            value={config.damping}
            onChange={(e) => onChange({ ...config, damping: Number(e.target.value) })}
            className="mt-2.5 h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-neutral-700 accent-pink-500"
          />
          <span className="mt-1 block text-[10px] text-neutral-500">Lower = More fluid bounce</span>
        </div>

        {/* Viscosity / Stretch Length */}
        <div className="rounded-2xl bg-neutral-800/50 p-3.5 border border-white/5">
          <div className="flex items-center justify-between text-xs font-medium text-neutral-300">
            <span>Liquid Stretch / Viscosity</span>
            <span className="font-mono text-sky-400">{config.viscosity.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="2.5"
            step="0.05"
            value={config.viscosity}
            onChange={(e) => onChange({ ...config, viscosity: Number(e.target.value) })}
            className="mt-2.5 h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-neutral-700 accent-sky-500"
          />
          <span className="mt-1 block text-[10px] text-neutral-500">Teardrop distortion length</span>
        </div>

        {/* RGB Split Chromatic Aberration */}
        <div className="rounded-2xl bg-neutral-800/50 p-3.5 border border-white/5">
          <div className="flex items-center justify-between text-xs font-medium text-neutral-300">
            <span>RGB Split Chromatic Glow</span>
            <span className="font-mono text-emerald-400">{config.rgbSplitStrength}px</span>
          </div>
          <input
            type="range"
            min="0"
            max="12"
            step="0.5"
            value={config.rgbSplitStrength}
            onChange={(e) =>
              onChange({ ...config, rgbSplitStrength: Number(e.target.value) })
            }
            className="mt-2.5 h-1.5 w-full cursor-pointer appearance-none rounded-lg bg-neutral-700 accent-emerald-500"
          />
          <span className="mt-1 block text-[10px] text-neutral-500">Velocity color bleed</span>
        </div>
      </div>

      {/* Mode Switches & Battery Saver Row */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-neutral-950/60 p-3 border border-white/5">
        <div className="flex flex-wrap items-center gap-2">
          {/* 120fps vs 60fps Battery Saver Toggle */}
          <button
            onClick={() =>
              onChange({
                ...config,
                targetFps: config.targetFps === 120 ? 60 : 120,
              })
            }
            className={`flex items-center space-x-1.5 rounded-xl px-3 py-1.5 text-xs font-medium transition-all ${
              config.targetFps === 120
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
            }`}
          >
            {config.targetFps === 120 ? (
              <Zap className="h-3.5 w-3.5 text-amber-400" />
            ) : (
              <Battery className="h-3.5 w-3.5 text-emerald-400" />
            )}
            <span>{config.targetFps === 120 ? '120 Hz Ultra FPS' : '60 Hz Battery Saver'}</span>
          </button>

          {/* RGB Split Toggle */}
          <button
            onClick={() => onChange({ ...config, enableRgbSplit: !config.enableRgbSplit })}
            className={`flex items-center space-x-1.5 rounded-xl px-3 py-1.5 text-xs font-medium transition-all ${
              config.enableRgbSplit
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>RGB Split Shader</span>
          </button>

          {/* Tab Set Switcher */}
          <button
            onClick={() => onToggleTabMode(tabMode === 'custom' ? 'music' : 'custom')}
            className="flex items-center space-x-1.5 rounded-xl bg-purple-500/20 px-3 py-1.5 text-xs font-medium text-purple-300 border border-purple-500/40 hover:bg-purple-500/30 transition-all"
          >
            <Palette className="h-3.5 w-3.5" />
            <span>
              Tabs: {tabMode === 'custom' ? 'Home / Card / Send / Assets' : 'Music Player Tabs'}
            </span>
          </button>
        </div>

        {/* Trigger Elastic Pulse Test Button */}
        <button
          onClick={onTriggerPulse}
          className="flex items-center space-x-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-lg hover:brightness-110 active:scale-95 transition-all"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>Trigger Elastic Pulse</span>
        </button>
      </div>
    </div>
  );
};
