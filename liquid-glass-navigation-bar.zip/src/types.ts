export interface TabItem {
  id: string;
  label: string;
  iconName: string;
  badge?: string | number;
  accentColor?: string;
}

export type NavItem = TabItem;

export interface PhysicsParams {
  stiffness: number;       // Spring stiffness (e.g., 180)
  damping: number;         // Spring damping ratio (0.35 - 0.95)
  mass: number;            // Indicator mass for momentum (0.5 - 2.0)
  stretchFactor: number;   // How much the indicator elongates during transit (0 - 1.5)
  blurRadius: number;      // Gooey blur radius in pixels (10 - 60)
  threshold: number;       // Liquid cutoff alpha threshold (0.2 - 0.8)
  rgbSplitStrength: number;// Chromatic aberration strength (0 - 0.05)
  glowIntensity: number;   // Outer edge glow bleed (0 - 1)
  pillHeightRatio: number; // Height ratio relative to container (0.5 - 0.85)
  albumColorBleed: boolean;// Reactively blend current album art color
}

export type PhysicsConfig = PhysicsParams;

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  durationSeconds?: number;
  coverUrl: string;
  accentColor: string; // Hex color extracted from album art
  secondaryColor: string;
  genre?: string;
  bitrate?: string;
  waveform?: number[];
}

export type TabSetMode = 'standard' | 'music' | 'custom';
