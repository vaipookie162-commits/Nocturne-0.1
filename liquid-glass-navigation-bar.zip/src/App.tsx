import React, { useState } from 'react';
import { NavItem, PhysicsParams, TabSetMode, Track } from './types';
import { STANDARD_TABS, MUSIC_TABS, TRACKS } from './data/musicData';
import { MusicPlayerView } from './components/MusicPlayerView';
import { PhysicsStudio } from './components/PhysicsStudio';
import { FpsMonitor } from './components/FpsMonitor';
import { CodeInspector } from './components/CodeInspector';
import { Sparkles, Smartphone, Sliders, Search } from 'lucide-react';

const DEFAULT_PHYSICS: PhysicsParams = {
  stiffness: 180,
  damping: 0.58,
  mass: 1.0,
  stretchFactor: 0.75,
  blurRadius: 40,
  threshold: 0.5,
  rgbSplitStrength: 0.025,
  glowIntensity: 0.6,
  pillHeightRatio: 0.72,
  albumColorBleed: true,
};

export default function App() {
  const [currentTrack, setCurrentTrack] = useState<Track>(TRACKS[0]);
  const [tabSetMode, setTabSetMode] = useState<TabSetMode>('standard');
  const [activeTabIndex, setActiveTabIndex] = useState(0);
  const [physics, setPhysics] = useState<PhysicsParams>(DEFAULT_PHYSICS);
  const [deviceFrame, setDeviceFrame] = useState(true);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);

  const activeTabs: NavItem[] = tabSetMode === 'standard' ? STANDARD_TABS : MUSIC_TABS;

  const handleSelectTabSet = (mode: TabSetMode) => {
    setTabSetMode(mode);
    setActiveTabIndex(0);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col items-center justify-between p-4 sm:p-6 lg:p-8 font-sans selection:bg-[#FF4E00] selection:text-white relative overflow-x-hidden">
      {/* Background Atmospheric Gradients */}
      <div className="fixed -top-[10%] -left-[10%] w-[60%] h-[60%] bg-[#FF4E00]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed -bottom-[20%] -right-[10%] w-[50%] h-[50%] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Header & Status */}
      <header className="w-full max-w-6xl flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-white/10 z-10">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-[#FF4E00]/20 transition-all duration-500 border border-white/10"
            style={{ backgroundColor: currentTrack.accentColor || '#FF4E00' }}
          >
            <Sparkles className="w-5 h-5 animate-pulse text-white" />
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-gray-500 font-bold block">
              Local Library • SoundScape
            </span>
            <h1 className="text-2xl font-semibold tracking-tight text-white flex items-center gap-2">
              SoundScape
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#FF4E00]/20 text-[#FF4E00] border border-[#FF4E00]/30 font-mono">
                120 FPS AGSL
              </span>
            </h1>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setDeviceFrame(!deviceFrame)}
            className="px-3.5 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-medium text-gray-300 hover:text-white transition-all flex items-center gap-2 cursor-pointer backdrop-blur-md"
          >
            <Smartphone className="w-4 h-4 text-[#FF4E00]" />
            {deviceFrame ? 'Device Frame' : 'Full Width'}
          </button>

          <button
            onClick={() => setIsStudioOpen(true)}
            className="px-4 py-2 rounded-2xl bg-gradient-to-r from-[#FF4E00] to-[#F27D26] hover:brightness-110 text-xs font-semibold text-white transition-all flex items-center gap-2 shadow-lg shadow-[#FF4E00]/20 cursor-pointer"
          >
            <Sliders className="w-4 h-4" />
            Physics & Shader Studio
          </button>

          <div className="w-10 h-10 rounded-full border-2 border-[#FF4E00] p-0.5 hidden sm:block">
            <div
              className="w-full h-full rounded-full transition-all duration-500"
              style={{ backgroundColor: currentTrack.accentColor || '#FF4E00' }}
            />
          </div>
        </div>
      </header>

      {/* Main Interactive Container */}
      <main className="w-full max-w-6xl my-6 flex flex-col items-center justify-center z-10">
        <MusicPlayerView
          tracks={TRACKS}
          currentTrack={currentTrack}
          onSelectTrack={setCurrentTrack}
          items={activeTabs}
          activeTabIndex={activeTabIndex}
          onSelectTab={setActiveTabIndex}
          physics={physics}
          deviceFrame={deviceFrame}
          onToggleFrame={() => setDeviceFrame(!deviceFrame)}
          onOpenPhysicsStudio={() => setIsStudioOpen(true)}
          isPlaying={isPlaying}
          onTogglePlay={() => setIsPlaying(!isPlaying)}
        />

        {/* FPS & Performance Monitor */}
        <FpsMonitor />

        {/* Source Code Inspector */}
        <CodeInspector />
      </main>

      {/* Physics Studio Modal */}
      <PhysicsStudio
        physics={physics}
        onChangePhysics={setPhysics}
        onResetPhysics={() => setPhysics(DEFAULT_PHYSICS)}
        tabSetMode={tabSetMode}
        onChangeTabSetMode={handleSelectTabSet}
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
      />

      {/* Footer */}
      <footer className="w-full max-w-6xl pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500 z-10">
        <p>SoundScape • Immersive UI Liquid Glass Navigation • Material 3 AGSL Shader Engine</p>
        <p className="font-mono text-[10px] tracking-widest uppercase">Android 13+ API 33 Standard</p>
      </footer>
    </div>
  );
}

