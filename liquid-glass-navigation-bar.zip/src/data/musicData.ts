import { NavItem, Track } from '../types';

export const STANDARD_TABS: NavItem[] = [
  { id: 'home', label: 'Home', iconName: 'Home' },
  { id: 'card', label: 'Card', iconName: 'CreditCard', badge: '2' },
  { id: 'send', label: 'Send', iconName: 'Send' },
  { id: 'assets', label: 'Assets', iconName: 'Sparkles' },
];

export const MUSIC_TABS: NavItem[] = [
  { id: 'home', label: 'Explore', iconName: 'Compass' },
  { id: 'search', label: 'Search', iconName: 'Search' },
  { id: 'library', label: 'Library', iconName: 'Music2', badge: '12' },
  { id: 'assets', label: 'Favorites', iconName: 'Heart' },
];

export const TRACKS: Track[] = [
  {
    id: '1',
    title: 'Midnight Liquid Odyssey',
    artist: 'Aether Wave & AGSL Collective',
    album: 'Chromatix Vol. 3',
    duration: '3:45',
    coverUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
    accentColor: '#3B82F6',
    secondaryColor: '#9333EA',
    waveform: [25, 40, 60, 30, 80, 95, 70, 50, 85, 100, 65, 40, 75, 90, 55, 30, 85, 60, 45, 70, 90, 100, 80, 50, 35, 65]
  },
  {
    id: '2',
    title: 'Neon Prism Horizon',
    artist: 'Material Synth Labs',
    album: 'Dynamic You',
    duration: '4:12',
    coverUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80',
    accentColor: '#EC4899',
    secondaryColor: '#8B5CF6',
    waveform: [30, 55, 70, 85, 90, 60, 40, 75, 95, 80, 60, 90, 100, 75, 50, 65, 85, 95, 70, 40, 60, 80, 90, 65, 45, 30]
  },
  {
    id: '3',
    title: 'Subtle Glass Reflections',
    artist: 'Jetpack Flow & Compose',
    album: 'Android 14 Shader Suite',
    duration: '2:58',
    coverUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600&auto=format&fit=crop&q=80',
    accentColor: '#10B981',
    secondaryColor: '#06B6D4',
    waveform: [20, 35, 50, 65, 80, 70, 90, 85, 60, 75, 95, 80, 55, 40, 70, 85, 90, 65, 50, 75, 85, 60, 45, 30, 25, 20]
  },
  {
    id: '4',
    title: '120Hz Fluid Motion',
    artist: 'RenderThread GPU Choir',
    album: 'Frame Perfect',
    duration: '5:04',
    coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    accentColor: '#F59E0B',
    secondaryColor: '#EF4444',
    waveform: [40, 60, 80, 95, 85, 70, 90, 100, 90, 75, 85, 95, 80, 65, 75, 90, 85, 70, 60, 80, 95, 90, 75, 55, 40, 30]
  }
];

export const AGSL_SHADER_CODE = `// Android Graphics Shading Language (AGSL) - Liquid Glass Morph & RGB Split
// Used with RenderEffect / RuntimeShader on Android 13+ (API 33+)

uniform float2 iResolution;     // Canvas dimension
uniform float  iProgress;        // Morph transition progress [0.0..1.0]
uniform float  iVelocity;        // High-velocity movement direction & speed
uniform float  iRGBStrength;     // Chromatic aberration multiplier
uniform float4 iAccentColor;     // Album art reactive accent tint
uniform shader composable;

half4 main(float2 fragCoord) {
    float2 uv = fragCoord / iResolution;
    float moveDir = sign(iVelocity);
    float speed = abs(iVelocity);
    
    // 1. Calculate dynamic Chromatic Aberration offset vector based on movement velocity
    float2 offsetR = float2(speed * iRGBStrength * 0.025 * moveDir, 0.0);
    float2 offsetB = float2(-speed * iRGBStrength * 0.025 * moveDir, 0.0);
    
    // 2. Evaluate RGB color channels with chromatic shift
    half r = composable.eval(fragCoord + offsetR * iResolution).r;
    half g = composable.eval(fragCoord).g;
    half b = composable.eval(fragCoord + offsetB * iResolution).b;
    half a = composable.eval(fragCoord).a;
    
    // 3. Gooey Alpha Thresholding (Metaball threshold calculation)
    half liquidAlpha = 0.0;
    if (a > 0.48) {
        liquidAlpha = smoothstep(0.48, 0.52, a);
    }
    
    // 4. Subtle Album Art Color Tint Bleed at trailing edge
    half3 baseColor = half3(r, g, b);
    half3 blendedColor = mix(baseColor, iAccentColor.rgb, speed * 0.15);
    
    return half4(blendedColor, liquidAlpha);
}
`;

export const JETPACK_COMPOSE_KOTLIN_CODE = `// Jetpack Compose - Liquid Glass Floating Capsule Bottom Navigation Bar
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CapsuleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

@Composable
fun LiquidGlassNavigationBar(
    items: List<Pair<String, ImageVector>>,
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit,
    accentColor: Color = Color(0xFF3B82F6),
    modifier: Modifier = Modifier
) {
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = 0.58f,
            stiffness = Spring.StiffnessLow
        ),
        label = "liquidIndex"
    )

    var lastIndex by remember { mutableFloatStateOf(0f) }
    val velocity = animatedIndex - lastIndex
    SideEffect { lastIndex = animatedIndex }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(72.dp)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    shape = CapsuleShape
                    clip = true
                    shadowElevation = 24.dp.toPx()
                }
                .background(Color(0xFF121318).copy(alpha = 0.88f))
        ) {
            LiquidIndicatorLayer(
                itemCount = items.size,
                indicatorOffset = animatedIndex,
                velocity = velocity,
                accentColor = accentColor
            )

            Row(modifier = Modifier.fillMaxSize()) {
                items.forEachIndexed { index, item ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onTabSelected(index) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.second,
                            contentDescription = item.first,
                            tint = if (selectedIndex == index) Color.Black else Color.White.copy(alpha = 0.5f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}
`;
